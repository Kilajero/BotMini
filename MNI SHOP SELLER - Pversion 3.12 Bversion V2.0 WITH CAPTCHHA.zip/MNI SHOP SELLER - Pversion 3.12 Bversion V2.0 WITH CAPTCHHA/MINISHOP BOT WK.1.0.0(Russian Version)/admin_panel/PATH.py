DB_PATH = __file__.replace("PATH.py", "database/db/")
LOGS = __file__.replace("PATH.py", "panel/logs.txt")
TEMP = __file__.replace("PATH.py", "temp/")
SETTINGS = TEMP + "settings.ini"