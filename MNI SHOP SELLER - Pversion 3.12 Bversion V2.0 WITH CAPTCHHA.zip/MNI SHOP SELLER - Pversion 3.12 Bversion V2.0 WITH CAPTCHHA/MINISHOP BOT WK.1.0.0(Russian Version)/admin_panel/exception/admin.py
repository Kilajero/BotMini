class AdminExistsError(Exception):
    pass
class AdminLimitError(Exception):
    pass
